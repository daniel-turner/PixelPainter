LAYOUT NOTES

Font: Roboto Slab Bold (Google Fonts)
Left column has a fixed with.
Layout is not mobile-responsive.
All included graphics should be included via background image styles.